# FS Writing Module

##ENG1003 / Focal Skills Writing
  
| Course Info |  | Instructor Info |  |
| -- | -- | -- | -- |
| Course Number |ENG1003  | Instructor Name | 0000 |
| Course Title |FS Writing  | Office Number | 0000 |
| Cycle/Year | C0 2016 | Phone Number | 0000 |
| Time & Place |  | Email | name@address.edu |
| Credit Hrs | 0000 | Office Hrs | dd : tt |

##Course Description
One paragraph description

##*Intended learning outcomes (ILOs)*
On completion of this course, students will be able to:

**ILO1**

**ILO2**

**ILO3**

**ILO4**

**ILO5**

##*Teaching and learning activities (TLAs)*
The following activities will ensure that students are able to achive the intended learning outcomes.

**TLA1**

**TLA2**

**TLA3**

**TLA4**

##*Assessment Tasks / Activities*

The following tasks / activities will provide evidence that students have achieved the Intended learning outcomes. (In some cases, a teaching and Learning Activity may also serve as an Assessment task.)

**AT1**

**AT2**

**AT3**

##*Assessment Criteria*
Short description of assessment criteria, may include tables. Assessment in modules is formative and intended to guide participants toward improved performance. 

Participants proceed to the next module once they achieve the target score in their four-weekly placement assessments.

