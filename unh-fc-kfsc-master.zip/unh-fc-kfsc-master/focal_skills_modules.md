# Focal Skills Modules
The Focal Skills Approach is based on four teaching and learning modules. These four modules are taken in the following order:
1. Listening
2. Reading
3. Writing
4. Advanced Topics

Placement in the various modules is governed by standardized placement tests which are administered at four-weekly intervals throughout the program.




